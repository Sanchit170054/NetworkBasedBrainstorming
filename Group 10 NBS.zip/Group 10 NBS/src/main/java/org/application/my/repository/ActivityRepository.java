package org.application.my.repository;

import org.application.my.modal.Activity;
import org.springframework.data.repository.CrudRepository;

public interface ActivityRepository extends CrudRepository<Activity, Integer> {

}
