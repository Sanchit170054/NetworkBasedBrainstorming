package org.application.my;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyApplication2Application {

	public static void main(String[] args) {
		SpringApplication.run(MyApplication2Application.class, args);
	}

}
